package patronCommand3;

public interface Command {
	void execute();
	  void revert();
}
