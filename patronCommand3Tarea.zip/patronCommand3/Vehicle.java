package patronCommand3;

public interface Vehicle {
	 void start();

	  void stop();

	  void accelerate();
	  
	  void decelerate();

}
