EncryptionStrategy (Interfaz)

Esta interfaz define el contrato para todas las estrategias de encriptación. Tiene tres métodos principales:

init(): Este método se utiliza para realizar cualquier inicialización necesaria antes de realizar el cifrado o descifrado. En las implementaciones proporcionadas (AESStrategy y CaesarStrategy), no se requiere ninguna inicialización, por lo que este método está vacío.

encrypt(byte[] data): Este método toma un arreglo de bytes data y lo encripta utilizando la estrategia de encriptación específica. Devuelve un arreglo de bytes que representa los datos encriptados.

decrypt(byte[] data): Este método toma un arreglo de bytes data encriptados y lo descifra utilizando la estrategia de encriptación específica. Devuelve una cadena que representa los datos descifrados.


AESStrategy (Clase)

Esta clase implementa la interfaz EncryptionStrategy y proporciona una implementación del algoritmo AES (Advanced Encryption Standard). Utiliza la biblioteca Java Cryptography Architecture (JCA) para realizar el cifrado y descifrado utilizando el modo de operación CBC (Cipher Block Chaining) con relleno PKCS5Padding.

El constructor de AESStrategy toma una clave (key) y un vector de inicialización (IV). Estos valores se utilizan para inicializar el cifrado AES. También proporciona un método init() que no realiza ninguna operación en la implementación actual.



CaesarStrategy (Clase)

Esta clase también implementa la interfaz EncryptionStrategy y proporciona una implementación del cifrado César. En el cifrado César, cada letra en el texto original se desplaza un número fijo de posiciones en el alfabeto.

El constructor de CaesarStrategy toma un parámetro shift que representa el número de posiciones a desplazar. Este valor determina la clave para el cifrado César.



StrategyContext (Clase)

Esta clase proporciona un contexto para utilizar las diferentes estrategias de encriptación. Toma una estrategia de encriptación (EncryptionStrategy) en su constructor y proporciona métodos convenientes para encriptar y desencriptar datos utilizando esa estrategia.



Main (Clase)

Esta clase contiene el método main, que sirve como punto de entrada del programa. En el método main, se crea una instancia de cada estrategia de encriptación (AESStrategy y CaesarStrategy), se utiliza un objeto StrategyContext para encriptar y desencriptar datos usando ambas estrategias, y se muestran los resultados en la salida estándar.