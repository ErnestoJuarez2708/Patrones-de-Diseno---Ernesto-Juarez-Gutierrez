package encriptacion;

public class CaesarStrategy implements EncryptionStrategy {

	private final int shift;

    public CaesarStrategy(int shift) {
        this.shift = shift;
    }

    @Override
    public void init() {
        // No initialization needed for Caesar Cipher
    }

    @Override
    public byte[] encrypt(byte[] data) {
    	byte[] encryptedData = new byte[data.length];
        for (int i = 0; i < data.length; i++) {
            byte originalByte = data[i];
            // Encrypt uppercase letters
            if (Character.isUpperCase(originalByte)) {
                encryptedData[i] = (byte) ((originalByte + shift - 65) % 26 + 65);
            }
            // Encrypt lowercase letters
            else if (Character.isLowerCase(originalByte)) {
                encryptedData[i] = (byte) ((originalByte + shift - 97) % 26 + 97);
            }
            // Non-alphabetic characters remain unchanged
            else {
                encryptedData[i] = originalByte;
            }
        }
        return encryptedData;
    }

    @Override
    public String decrypt(byte[] data) {
    	byte[] decryptedData = new byte[data.length];
        for (int i = 0; i < data.length; i++) {
            byte originalByte = data[i];
            // Decrypt uppercase letters
            if (Character.isUpperCase(originalByte)) {
                decryptedData[i] = (byte) ((originalByte - shift - 65 + 26) % 26 + 65);
            }
            // Decrypt lowercase letters
            else if (Character.isLowerCase(originalByte)) {
                decryptedData[i] = (byte) ((originalByte - shift - 97 + 26) % 26 + 97);
            }
            // Non-alphabetic characters remain unchanged
            else {
                decryptedData[i] = originalByte;
            }
        }
        return new String(decryptedData);
    }

}
