package encriptacion;

public class Main {

    public static void main(String[] args) {
        String word = "Empleando Strategy";

        // Inicializar estrategia y contexto para AES
        byte[] aesKey = "0123456789abcdef".getBytes(); // Clave de ejemplo para AES
        byte[] aesIV = "0123456789abcdef".getBytes();  // IV de ejemplo para AES
        EncryptionStrategy aesStrategy = new AESStrategy(aesKey, aesIV);
        StrategyContext aesContext = new StrategyContext(aesStrategy);

        // Encriptar y desencriptar usando AES
        byte[] aesEncrypted = aesContext.encryptText(word.getBytes());
        String aesDecrypted = aesContext.decryptText(aesEncrypted);

        // Inicializar estrategia y contexto para Cifrado César
        EncryptionStrategy caesarStrategy = new CaesarStrategy(3);
        StrategyContext caesarContext = new StrategyContext(caesarStrategy);

        // Encriptar y desencriptar usando Cifrado César
        byte[] caesarEncrypted = caesarContext.encryptText(word.getBytes());
        String caesarDecrypted = caesarContext.decryptText(caesarEncrypted);

        // Mostrar resultados
        System.out.println("AES:");
        System.out.println("Encriptado: " + new String(aesEncrypted));
        System.out.println("Desencriptado: " + aesDecrypted);

        System.out.println("Caesa:");
        System.out.println("Encriptado: " + new String(caesarEncrypted));
        System.out.println("Desencriptado: " + caesarDecrypted);
    }
}

