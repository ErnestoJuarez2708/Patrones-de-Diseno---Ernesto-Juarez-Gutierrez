/**
 * 
 */
/**
 * 
 */
module PatronEstrategy {
}