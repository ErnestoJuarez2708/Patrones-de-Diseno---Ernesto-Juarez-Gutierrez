package edu.upb.lp.progra.ernestopo;

public class AparecerTopo implements Runnable {
    private ErnestopoGame game;
    private boolean running = false;

    public AparecerTopo(ErnestopoGame game) {
        this.game = game;
    }

    public void start() {
        if (!running) {
            running = true;
            run();
        }
    }

    public void stop() {
        running = false;
    }

    @Override
    public void run() {
        if (running) {
            game.iscoming();
        }
    }
}