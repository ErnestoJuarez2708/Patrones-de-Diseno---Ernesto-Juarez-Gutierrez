package edu.upb.lp.progra.ernestopo;

public interface Topo {
    public int getPuntos ();
    public int getTiempo ();
    public String getAspecto ();
    public int bonus();
    public void setPuntuacion(int puntuacion);
    public void setTiempo(int tiempo);
    public void setAspecto(String aspecto);
    public void setBonus(int bonus);


}
