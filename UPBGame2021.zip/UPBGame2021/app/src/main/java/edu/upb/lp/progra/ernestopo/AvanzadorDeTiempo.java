package edu.upb.lp.progra.ernestopo;

public class AvanzadorDeTiempo implements Runnable {
    private ErnestopoGame game;
    private boolean running = false;

    public AvanzadorDeTiempo(ErnestopoGame game) {
        this.game = game;
    }

    public void start() {
        if (!running) {
            running = true;
            run();
        }
    }

    public void stop() {
        running = false;
    }

    @Override
    public void run() {
        if (running) {
            game.avanzarTiempo();
            game.executeLater(this, 1000);
        }
    }
}
