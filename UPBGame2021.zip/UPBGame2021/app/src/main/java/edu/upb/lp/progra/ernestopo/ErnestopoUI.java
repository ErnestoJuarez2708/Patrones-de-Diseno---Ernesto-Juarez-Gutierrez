package edu.upb.lp.progra.ernestopo;


import edu.upb.lp.progra.adapterFiles.AndroidGameGUI;
import edu.upb.lp.progra.adapterFiles.UI;

public class ErnestopoUI implements UI {
    private AndroidGameGUI gui;
    private ErnestopoGame game = new ErnestopoGame(this);
    private int pantalla = 0;
    private int a;

    public ErnestopoUI(AndroidGameGUI gui){

        this.gui= gui;

    }


    @Override
    public void onButtonPressed(String name) {
        if(name.equals("Start")) {
            game.iniciarTiempo();
            game.iniciarTopos();
            gui.removeButton("Start");
            gui.addButton("Restart",15,40);
        } else if (name.equals("Restart")) {
            game.detenerTodo();
            gui.removeButton("Restart");
            gui.addButton("Start",15,40);
        }
    }

    @Override
    public void onCellPressed(int vertical, int horizontal) {
        if (pantalla == 0) {
            pantallaDeHistorio();
            pantalla++;
        } else if(pantalla == 1){
            pantallaDeHistori2();
            pantalla++;
        } else if (pantalla == 2) {
            pantallaDificultSelector();
            pantalla++;
        }else if (pantalla == 3) {
            a = game.seleccionDeDificultad(vertical, horizontal);
            pantalla++;
            pantallaDeJuego();
        }else {
            game.topoDifficult(vertical,horizontal,a);
        }
    }

    @Override
    public void initialiseInterface() {
        gui.configureScreen(1, 1, 0, 0, true, 0);
        gui.setImageOnCell(0,0,"pantalla_uno");
    }
    public void pantallaDeHistorio() {
        gui.configureScreen(1, 1, 0, 0, true, 0);
        gui.setImageOnCell(0,0,"pantalla_dos");
    }

    public void pantallaDeHistori2() {
        gui.configureScreen(1, 1, 0, 0, true, 0);
        gui.setImageOnCell(0,0,"pantalla_3");
    }
    public void pantallaDificultSelector(){
        gui.configureScreen(3,1,20,0,true,0);
        gui.setImageOnCell(0,0,"easy");
        gui.setImageOnCell(1,0,"medium");
        gui.setImageOnCell(2,0,"hard");
    }
    public void pantallaDeJuego() {
        gui.configureScreen(5, 4, 0, 0, true, 0.3);
        for(int h=0;h<4;h++) //horizontal
        {
            gui.setImageOnCell(0,h,"sky");
        }
        for (int h = 1; h < 5; h++) { //filas

            for (int v = 0; v < 4; v++) { //columnas
                gui.setImageOnCell(h, v, "hoyo_topo");
            }
        }

        gui.addButton("Start", 20, 40);
        gui.addTextField("TimeText", "2:00",20,40);
        gui.addTextField("Puntuacion","Puntuacion " + game.getPuntuacion() ,20,40);
    }

    public void actualizarTiempo(String tiempo) {

        gui.updateTextField("TimeText", tiempo);

    }

    public void timeOut() {

        gui.showTemporaryMessage("Time out");

    }

    public void executeLater(Runnable r, int ms) {
        gui.executeLater(r,ms);
    }

    public void mostrarTopo(int v, int h, String nombreTopo) {
        gui.setImageOnCell(v,h,nombreTopo);
    }

    public void actualizarPuntaje(int puntos) {
        gui.updateTextField("Puntuacion", "Puntuacion "+ puntos);
    }


    public void borrarTopo(int vertical, int horizontal) {
        gui.setImageOnCell(vertical,horizontal, "hoyo_topo");
    }


    public void removerBoton() {
        gui.removeButton("Restart");
    }



}


