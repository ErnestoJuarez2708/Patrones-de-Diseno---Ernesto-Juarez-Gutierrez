package edu.upb.lp.progra.ernestopo;

public class Ernestotopo implements Topo{
    private ErnestopoGame game;

    private int puntuacion;
    private String aspecto;
    private int tiempo;

    private int bonus;

    public Ernestotopo(ErnestopoGame game, int puntuacion, String aspecto, int tiempo, int bonus) {
        this.game = game;
        this.puntuacion = puntuacion;
        this.aspecto = aspecto;
        this.tiempo = tiempo;
        this.bonus = bonus;
    }

    public void setPuntuacion(int puntuacion){
        this.puntuacion = puntuacion;
    }

    @Override
    public void setTiempo(int tiempo) {
        this.tiempo = tiempo;
    }

    @Override
    public void setAspecto(String aspecto) {
        this.aspecto = aspecto;
    }

    @Override
    public void setBonus(int bonus) {
        this.bonus = bonus;
    }

    @Override
    public int getPuntos() {
        return puntuacion;
    }

    @Override
    public String getAspecto() {
        return aspecto;
    }

    @Override
    public int bonus() {
        return bonus;
    }

    @Override
    public int getTiempo() {
        return tiempo;
    }

}
