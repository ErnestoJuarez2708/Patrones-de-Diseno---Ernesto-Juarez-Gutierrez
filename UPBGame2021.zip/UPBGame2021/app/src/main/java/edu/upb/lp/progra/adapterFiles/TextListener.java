package edu.upb.lp.progra.adapterFiles;

public interface TextListener {
	public void receiveText(String text);
}
