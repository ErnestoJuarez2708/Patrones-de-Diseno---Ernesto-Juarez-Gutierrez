package edu.upb.lp.progra.ernestopo;

public class TopoFactory{ //Clase para la creacion de Topos
    private ErnestopoGame game;
    private int tipo;

    public TopoFactory(int tipo, ErnestopoGame game){
        this.tipo = tipo;
        this.game = game;
    }

    public Topo crearTopo(int tipo, ErnestopoGame game) {
        switch (tipo) {
            case 1:
                return new Ernestotopo(game,70,"topo_two",1200,0);
                case 2:
                    return new Luis(game,100,"topo_one",1000,5);
                case 3:
                    return new Diego(game,-50,"topo_three",1400,-5);
                case 4:
                    return new Vale(game,0,"topo_10",1300,10);
                default:
                    throw new IllegalArgumentException("Tipo de topo desconocido: " + tipo);
            }
    }

    public Topo crearTopoMedium(int tipo, ErnestopoGame game) {
        switch (tipo) {
            case 1:
                return new Ernestotopo(game,50,"topo_4",1000,0);
            case 2:
                return new Luis(game,80,"topo_6",800,3);
            case 3:
                return new Diego(game,-100,"topo_8",1500,-10);
            case 4:
                return new Vale(game,0,"topo_11",1100,8);
            default:
                throw new IllegalArgumentException("Tipo de topo desconocido: " + tipo);
        }
    }
    public Topo crearTopoHard(int tipo, ErnestopoGame game) {
        switch (tipo) {
            case 1:
                return new Ernestotopo(game,30,"topo_5",800,0);
            case 2:
                return new Luis(game,50,"topo_7",500,1);
            case 3:
                return new Diego(game,-150,"topo_9",1600,-15);
            case 4:
                return new Vale(game,0,"topo_12",900,5);
            default:
                throw new IllegalArgumentException("Tipo de topo desconocido: " + tipo);
        }
    }

}
