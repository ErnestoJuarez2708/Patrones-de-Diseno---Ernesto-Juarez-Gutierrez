package edu.upb.lp.progra.ernestopo;
import java.util.Random;

public class ErnestopoGame {

    private ErnestopoUI ui;
    private int puntuacion = 0;
    private int[][] hoyo = new int[6][4]; // 0: vacia, 1: ernestotopo, 2: luis, 3: diego
    private int minuto = 2;
    private int segundos = 0;
    private AparecerTopo aparecer = new AparecerTopo(this);
    private DesaparecerTopo desaparecer = new DesaparecerTopo(this);
    private AvanzadorDeTiempo avanzador = new AvanzadorDeTiempo(this);
    private Random random = new Random();
    private int vertical; // coordenadas
    private int horizontal;
    private int topo; // qué topo es
    int vuelta;

    private TopoFactory fabrica =  new TopoFactory(topo,this);


    public ErnestopoGame(ErnestopoUI ui) {
        this.ui = ui;
    }


//Algo mal aca,



    public void avanzarTiempo() {
        String t = "";
        t += minuto + ":";
        if (segundos <= 9)
            t += ("0" + segundos);
        else
            t += segundos;
        segundos--;
        ui.actualizarTiempo(t);
        if (segundos < 0) {
            minuto--;
            segundos = 59;
        }
        if (minuto < 0) {
            detenerTodo();
            ui.timeOut();
            ui.removerBoton();
        }
    }

    public void executeLater(Runnable r, int ms) {
        ui.executeLater(r, ms);
    }

    public void iniciarTiempo() {
        ui.actualizarPuntaje(0);
        avanzador.start();
    }

    public int topoAleatorio() {
        int valor = random.nextInt(10);
        valor++;
        if (valor <=1)
            return 4;
        else if (valor <= 3)
            return 2;
        else if (valor <= 5)
            return 3;
        else
            return 1;
    }
    public int seleccionDeDificultad(int vertical, int horizontal){
        System.out.println(vertical + horizontal);
        if (vertical == 0 && horizontal == 0) {
            topoDifficult(vertical, horizontal,1);
            vuelta = 1;
        } else if (vertical == 1 && horizontal == 0) {
            topoDifficult(vertical, horizontal,2);
            vuelta = 2;
        } else if (vertical == 2 && horizontal == 0) {
            topoDifficult(vertical, horizontal,3);
            vuelta = 3;
        }
        return vuelta;
    }

    public void iscoming() {
        int v = random.nextInt(4) + 1, h = random.nextInt(4);
        topo = topoAleatorio();
        vertical = v;
        horizontal = h;
        hoyo[v][h] = topo;
        if (vuelta == 1) {
            Topo nuevoTopo = fabrica.crearTopo(topo, this);
            ui.mostrarTopo(v, h, nuevoTopo.getAspecto());
            ui.executeLater(desaparecer, nuevoTopo.getTiempo());
        } else if (vuelta == 2) {
            Topo nuevoTopo = fabrica.crearTopoMedium(topo, this);
            ui.mostrarTopo(v, h, nuevoTopo.getAspecto());
            ui.executeLater(desaparecer, nuevoTopo.getTiempo());
        } else if (vuelta == 3) {
            Topo nuevoTopo = fabrica.crearTopoHard(topo, this);
            ui.mostrarTopo(v, h, nuevoTopo.getAspecto());
            ui.executeLater(desaparecer, nuevoTopo.getTiempo());
        }
        System.out.println("Vuelta : " + vuelta);
    }
    public void topoDifficult(int vertical, int horizontal,int tipo){
            if (hoyo[vertical][horizontal] > 0) {
                if(tipo == 1){
                    Topo topoSeleccionado = fabrica.crearTopo(hoyo[vertical][horizontal], this);
                    topoAtributos(vertical,horizontal,topoSeleccionado);
                }else if (tipo==2){
                    Topo topoSeleccionado = fabrica.crearTopoMedium(hoyo[vertical][horizontal], this);
                    topoAtributos(vertical,horizontal,topoSeleccionado);
                }else{
                    Topo topoSeleccionado = fabrica.crearTopoHard(hoyo[vertical][horizontal], this);
                    topoAtributos(vertical,horizontal,topoSeleccionado);
                }
            }
    }

    public void topoAtributos(int vertical, int horizontal, Topo tipo ){
        puntuacion += tipo.getPuntos();
        segundos += tipo.bonus();
        hoyo[vertical][horizontal] = 0;
        ui.borrarTopo(vertical, horizontal);
        if (segundos >= 60) {
            minuto++;
            segundos -= 60;
        }
        String tiempo = minuto + ":";
        if (segundos <= 9)
            tiempo += ("0" + segundos);
        else
            tiempo += segundos;
        ui.actualizarTiempo(tiempo);
        ui.actualizarPuntaje(puntuacion);
        if (minuto < 0) {
            detenerTodo();
            ui.timeOut();
            ui.removerBoton();
        }
    }
    public void ocultarTopo() {
        hoyo[vertical][horizontal] = 0;
        ui.borrarTopo(vertical, horizontal);
        ui.executeLater(aparecer, 100);
    }

    public void iniciarTopos() {
        aparecer.start();
        desaparecer.start();
    }

    public void detenerTodo() {
        minuto = 2;
        segundos = 0;
        avanzador.stop();
        aparecer.stop();
        desaparecer.stop();
        ui.pantallaDeJuego();
        ui.actualizarTiempo("2:00");
        ui.actualizarPuntaje(puntuacion);
        puntuacion = 0;
    }

    public int getPuntuacion() {
        return puntuacion;
    }

}


