package edu.upb.lp.progra.ernestopo;

public class Vale implements Topo{
    private ErnestopoGame game;
    private int puntuacion;
    private int tiempo;
    private String aspecto;
    private int bonus;

    public Vale(ErnestopoGame game, int puntuacion, String aspecto, int tiempo, int bonus) {
        this.game = game;
        this.puntuacion = puntuacion;
        this.aspecto = aspecto;
        this.tiempo = tiempo;
        this.bonus = bonus;
    }
    @Override
    public int getPuntos() {
        return puntuacion;
    }

    @Override
    public int getTiempo() {
        return tiempo;
    }

    @Override
    public String getAspecto() {
        return aspecto;
    }

    @Override
    public int bonus() {
        return bonus;
    }

    @Override
    public void setPuntuacion(int puntuacion) {
        this.puntuacion = puntuacion;
    }

    @Override
    public void setTiempo(int tiempo) {
        this.tiempo = tiempo;
    }

    @Override
    public void setAspecto(String aspecto) {
        this.aspecto =aspecto;
    }

    @Override
    public void setBonus(int bonus) {
        this.bonus = bonus;
    }
}
