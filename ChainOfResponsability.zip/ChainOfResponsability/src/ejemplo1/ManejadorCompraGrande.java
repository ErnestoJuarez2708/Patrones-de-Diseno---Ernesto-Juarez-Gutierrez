package ejemplo1;

public class ManejadorCompraGrande extends BaseManejador {
	
	@Override
    public void manejarSolicitud(SolicitudCompra solicitud) {
        System.out.println("Compra aprobada por el Manejador de Compra Grande.");
    }
}
