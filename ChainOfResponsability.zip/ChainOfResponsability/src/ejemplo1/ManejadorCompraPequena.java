package ejemplo1;

public class ManejadorCompraPequena extends BaseManejador{
	private static final double LIMITE = 100.0;
	

    @Override
    public void manejarSolicitud(SolicitudCompra solicitud) {
        if (solicitud.getMonto() <= LIMITE) {
            System.out.println("Compra aprobada por el Manejador de Compra Pequeña.");
        } else {
            pasarSolicitudAlSiguiente(solicitud);
        }
    }
}
