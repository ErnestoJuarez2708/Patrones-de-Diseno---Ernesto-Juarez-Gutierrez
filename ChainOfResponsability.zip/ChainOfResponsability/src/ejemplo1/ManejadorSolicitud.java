package ejemplo1;

public interface ManejadorSolicitud {
	void manejarSolicitud(SolicitudCompra solicitud);

	void setSiguienteManejador(ManejadorSolicitud manejadorCompraMediana);
}
