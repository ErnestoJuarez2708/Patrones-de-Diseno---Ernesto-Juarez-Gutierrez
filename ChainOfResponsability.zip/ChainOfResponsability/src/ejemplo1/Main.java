package ejemplo1;


public class Main {

	public static void main(String[] args) {
		ManejadorSolicitud manejadorCompraPequena = new ManejadorCompraPequena();
        ManejadorSolicitud manejadorCompraMediana = new ManejadorCompraMediana();
        ManejadorSolicitud manejadorCompraGrande = new ManejadorCompraGrande();

        // Configurar la cadena de responsabilidad
        manejadorCompraPequena.setSiguienteManejador(manejadorCompraMediana);
       //manejadorCompraMediana.setSiguienteManejador(manejadorCompraGrande);

        
        // Probar con diferentes montos de compra
        SolicitudCompra solicitud1 = new SolicitudCompra(50.0);
       SolicitudCompra solicitud2 = new SolicitudCompra(300.0);
       SolicitudCompra solicitud3 = new SolicitudCompra(1000.0);
       // SolicitudCompra solicitud4 = new SolicitudCompra(20.0);

        
        // Procesar las solicitudes
        manejadorCompraPequena.manejarSolicitud(solicitud2);
      // manejadorCompraMediana.manejarSolicitud(solicitud2);
	} 

}
