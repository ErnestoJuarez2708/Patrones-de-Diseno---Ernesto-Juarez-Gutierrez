package ejemplo1;

public class ManejadorCompraMediana extends BaseManejador{
	private static final double LIMITE = 500.0;
	

    @Override
    public void manejarSolicitud(SolicitudCompra solicitud) {
        if (solicitud.getMonto() <= LIMITE) {
            System.out.println("Compra aprobada por el Manejador de Compra Mediana.");
        } else {
            pasarSolicitudAlSiguiente(solicitud);
        }
    }
}
