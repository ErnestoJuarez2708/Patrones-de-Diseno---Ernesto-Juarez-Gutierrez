package ejemplo1;

public abstract class BaseManejador implements ManejadorSolicitud {
	
	private ManejadorSolicitud siguienteManejador;

    public void setSiguienteManejador(ManejadorSolicitud siguienteManejador) {
        this.siguienteManejador = siguienteManejador;
    }

    public void pasarSolicitudAlSiguiente( SolicitudCompra solicitud) {
        if (siguienteManejador != null) {
            siguienteManejador.manejarSolicitud(solicitud);
        } else {
            System.out.println("No se pudo manejar la solicitud.");
        }
    }

	
}
