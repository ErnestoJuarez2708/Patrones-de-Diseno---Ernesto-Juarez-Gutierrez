import java.util.List;

public interface FeedParser {
    public List<Flower> parse(String content);
}
